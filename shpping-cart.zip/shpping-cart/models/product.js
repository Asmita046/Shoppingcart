var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var schema=new Schema({
    imagepath:{type:String,require:true},
    title:{type:String,require:true},
    Description:{type:String,require:true},
    price:{type:String,require:true},
});

module.exports=mongoose.model('Product',schema);