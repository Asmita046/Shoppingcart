var Product=require('../models/product');

var mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/shopping',{useNewUrlParser:true, useUnifiedTopology:true});

var products=[
    new Product({
        imagepath:'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Gothiccover.png/220px-Gothiccover.png',
        title:'Gothic Video Game',
        Description:'Gone !!!!!',
        price:18
    }),
    new Product({
        imagepath:'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Gothiccover.png/220px-Gothiccover.png',
        title:'Gothic Video Game',
        Description:'Gone !!!!!',
        price:1
    }),
    new Product({
        imagepath:'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Gothiccover.png/220px-Gothiccover.png',
        title:'Gothic Video Game',
        Description:'Gone !!!!!',
        price:8
    }),
    new Product({
        imagepath:'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Gothiccover.png/220px-Gothiccover.png',
        title:'Gothic Video Game',
        Description:'Gone !!!!!',
        price:5
    }),
    new Product({
        imagepath:'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Gothiccover.png/220px-Gothiccover.png',
        title:'Gothic Video Game',
        Description:'Gone !!!!!',
        price:4
    }),
    new Product({
        imagepath:'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/Gothiccover.png/220px-Gothiccover.png',
        title:'Gothic Video Game',
        Description:'Gone !!!!!',
        price:6
    })
];

var done=0;
for (var i=0;i<products.length;i++){
    products[i].save(function(err,result){
        done++;
        if(done== products.length){
            exit();
        }
    });
}

function exit(){
    mongoose.disconnect();
}